import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registraion-component',
  templateUrl: './registraion-component.component.html',
  styleUrls: ['./registraion-component.component.scss']
})
export class RegistraionComponentComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {
  }

}
