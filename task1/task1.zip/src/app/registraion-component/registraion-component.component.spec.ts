import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistraionComponentComponent } from './registraion-component.component';

describe('RegistraionComponentComponent', () => {
  let component: RegistraionComponentComponent;
  let fixture: ComponentFixture<RegistraionComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistraionComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegistraionComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
